library(trimcluster)
example(trimkmeans)
