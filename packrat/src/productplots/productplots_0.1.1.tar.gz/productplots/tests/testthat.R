library(testthat)
library(productplots)

test_check("productplots")
