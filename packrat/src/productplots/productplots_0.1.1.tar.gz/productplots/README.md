# productplots

[![Travis-CI Build Status](https://travis-ci.org/hadley/productplots.svg?branch=master)](https://travis-ci.org/hadley/productplots)
[![Coverage Status](https://img.shields.io/codecov/c/github/hadley/productplots/master.svg)](https://codecov.io/github/hadley/productplots?branch=master)

## Installation

You can install productplots from github with:

```R
# install.packages("devtools")
devtools::install_github("hadley/productplots")
```
