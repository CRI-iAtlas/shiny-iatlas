### =========================================================================
### The normalize() generic
### -------------------------------------------------------------------------

setGeneric("normalize", 
    function(object, ...) standardGeneric("normalize")
)

