### - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
### Row-level and column-level summary
###

setGeneric("rowSums", signature="x")
setGeneric("colSums", signature="x")
setGeneric("rowMeans", signature="x")
setGeneric("colMeans", signature="x")
