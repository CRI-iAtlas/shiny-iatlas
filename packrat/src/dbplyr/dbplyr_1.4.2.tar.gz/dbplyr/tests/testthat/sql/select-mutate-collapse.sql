$a
<SQL>
SELECT 1.0 AS `a`
FROM `df`

$x
<SQL>
SELECT `x`
FROM `df`

