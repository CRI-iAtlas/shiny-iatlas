#define SQLITE_CORE
#include "vendor/sqlite3/regexp.c"
