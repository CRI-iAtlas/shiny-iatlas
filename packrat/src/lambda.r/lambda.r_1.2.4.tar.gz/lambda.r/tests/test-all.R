library(testit)
test_pkg('lambda.r')

